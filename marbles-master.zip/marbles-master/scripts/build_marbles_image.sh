#!/bin/bash

docker build -t marbles:local -f Dockerfile ../